//VEDIC PARTAP 16CS 10053 SECTION 5
//STRUCTURE FORMATION
#include<stdio.h>
#include<stdlib.h>
struct record  //STRUCT DECLARARTION
{
  int roll;
  char name[20];
  int age;
};
int main()
{
  int n;
  printf("Give the number of the student : ");//ACCEPTING THE NUMBER OF STUDENT
  scanf("%d",&n);
  struct record a[n];
  int i;
  for(i=0;i<n;i++)
    {
      printf("Enter the roll no of student %d : ",i+1);//ACCEPTING THE ELEMENTS 
      scanf("%d",&a[i].roll);
      getchar();//FOR THE ENTER KEY
      printf("Enter the name of the student %d :",i+1);
      scanf("%[^\n]%*c",&a[i].name);
      printf("Enter the age of the student %d : ",i+1);
      scanf("%d",&a[i].age);
    }
  printf("The output is :\n");
  int j;
  for(j=0;j<n;j++)
  {
    printf("Student[%d] = %d %s %d\n",j+1,a[j].roll,a[j].name,a[j].age);//PRINTING THE ARRAY
  }
  return 0; 
}
