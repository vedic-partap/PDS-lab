//VEDIC PARTAP 16CS 10053 SECTION 5
//CREATING THE LINKED LIST

#include<stdio.h>
#include<stdlib.h>

struct record  //STRUCT FOR RECORD
{
  int roll;
  char name[20];
  int age;
};
struct node  //STRUCT FOR THE LIST
{
  struct record data;
  struct node * next;
};
struct node * createList(int n)  //FUNCTION TO CREATE THE LIST
{
  struct node *header,*temp,*new;
  new=(struct node *)malloc(sizeof(struct node));
  printf("Enter the roll no of student: ");
      scanf("%d",&new->data.roll);
      getchar();
      printf("Enter the name of the student :");
      scanf("%[^\n]%*c",new->data.name);
      printf("Enter the age of the student : ");
      scanf("%d",&new->data.age);
      new->next=NULL;
      header=new;
      temp=new;
      int i;
      for(i=1;i<n;i++)
	{
	  new=(struct node *)malloc(sizeof(struct node));
	  printf("Enter the roll no of student: ");
	  scanf("%d",&new->data.roll);
	  getchar();
	  printf("Enter the name of the student:");
	  scanf("%[^\n]%*c",new->data.name);
	  printf("Enter the age of the student : ");
	  scanf("%d",&new->data.age);
	  new->next=NULL;
	  temp->next=new;
	  temp=new;
	}
      return header;
}void print_list(struct node * header) //FUNCTION TO PRINT THE LIST ...
{
  struct node *temp;
  temp=header;
  printf("Student[1] = %d %s %d\n",temp->data.roll,temp->data.name,temp->data.age);
  int i;
  for(i=1;temp->next!=NULL;i++)
    {
      temp=temp->next;
      printf("Student[%d]= %d %s %d\n",i+1,temp->data.roll,temp->data.name,temp->data.age);
    }
  return ;
}
int main()
{
  int n;
  printf("Give the value of the number of student : ");
  scanf("%d",&n);
  struct node * header;
  header=createList(n);
  print_list(header);
  return 0;
}
