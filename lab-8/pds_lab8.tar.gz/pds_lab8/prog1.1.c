//VEDIC PARTAP  16CS10053 SECTION 5
//USING POINTER

#include<stdio.h>
#include<stdlib.h>
struct record //STRUCT DECLARARTION
{
  int roll;
  char name[20];
  int age;
};

int main()
{
  int n;
  printf("Give the number of the student : ");
  scanf("%d",&n);
  struct record *a;//DECLARING THE POINTER 
  a=(struct record *)malloc(n*sizeof(struct record));//ALLOCATING THE MEMORY
  int i;
  for(i=0;i<n;i++)
    {
      printf("Enter the roll no of student %d : ",i+1);//ASSIGNING THE VAUES 
      scanf("%d",&(a+i)->roll);
      getchar();
      printf("Enter the name of the student %d :",i+1);
      scanf("%[^\n]%*c",(a+i)->name);
      printf("Enter the age of the student %d : ",i+1);
      scanf("%d",&(a+i)->age );
    }
  printf("The output is :\n");
  int j;
  for(j=0;j<n;j++)
  {
    printf("Student[%d] = %d %s %d\n",j+1, ((a+j)->roll),((a+j)->name),((a+j)->age));//PRINTING THE OUTPUT
  }
  return 0; 
}
