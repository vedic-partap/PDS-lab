//VEDIC PARTAP  16CS 10053 SECTION 5
//MARKS 
#include<stdio.h>
struct marks  //STRUCT FOR THE MARKS 
{
  float sub1,sub2,sub3,sub4,total;
  char result;
};
struct record  //STRUCT FOR THE RECORD
{
  int roll;
  char name[20];
  int age;
  struct marks m;
};
void total_sort(struct record a[],int n)  //SORTING ACCORDING THE TOTAL MARKS
{
  int count=1,i,j;
  while(count!=0)
    {
      count=0;
      for(i=1;i<n;i++)
	{
	  if(a[i].m.total<a[i-1].m.total)
	    {
	      struct record temp;
	      a[i]=a[i-1];
	      a[i-1]=temp;
	      count++;
	    }
	}
    }
}
int main()
{
 int n;
  printf("Give the number of the student : ");
  scanf("%d",&n);
  struct record a[n];
  int i;
  for(i=0;i<n;i++)
    {
      printf("Enter the roll no of student %d : ",i+1);//ACCEPTING THE ELEMENTS 
      scanf("%d",&a[i].roll);
      getchar();
      printf("Enter the name of the student %d :",i+1);
      scanf("%[^\n]%*c",&a[i].name);
      printf("Enter the age of the student %d : ",i+1);
      scanf("%d",&a[i].age);
      printf("Give marks in Subject 1 of student %d  :",i+1);
      scanf("%f",&(a[i].m).sub1);
      printf("Give marks in Subject 2 of student %d  :",i+1);
      scanf("%f",&(a[i].m).sub2);
      printf("Give marks in Subject 3 of student %d  :",i+1);
      scanf("%f",&(a[i].m).sub3);
      printf("Give marks in Subject 4 of student %d  :",i+1);
      scanf("%f",&(a[i].m).sub4);
      float temp;
      a[i].m.total=a[i].m.sub1+a[i].m.sub2+a[i].m.sub3+a[i].m.sub4;
      temp=a[i].m.total/40.0;
      if(temp>=9)
	a[i].m.result='E';                        //ASSIGNING THE GRADES
      else if(temp>=8 && temp<9)
	a[i].m.result='A';
      else if(temp>=7 && temp<8)
	a[i].m.result='B';
      else if(temp>=6 && temp<7)
	a[i].m.result='C';
      else if(temp>=5 && temp<6)
	a[i].m.result='D';
      else if(temp>=4 && temp<5)
	a[i].m.result='P';
      else
	a[i].m.result='F';
	
    }
  printf("Before sorting : \n");
  for(i=0;i<n;i++)
    {
      printf("Student[%d] = %d %s %d ",i+1,a[i].roll,a[i].name,a[i].age);
      printf("%.2f %.2f %.2f %.2f %.2f %c\n",a[i].m.sub1,a[i].m.sub2,a[i].m.sub3,a[i].m.sub4,a[i].m.total,a[i].m.result);//PRINTING THE RESULT
    }
  printf("Sorting By Total marks :\n");
  total_sort(a,n);
for(i=0;i<n;i++)
    {
      printf("Student[%d] = %d %s %d ",i+1,a[i].roll,a[i].name,a[i].age);
      printf("%.2f %.2f %.2f %.2f %.2f %c\n",a[i].m.sub1,a[i].m.sub2,a[i].m.sub3,a[i].m.sub4,a[i].m.total,a[i].m.result);
    }
 return 0;
}
