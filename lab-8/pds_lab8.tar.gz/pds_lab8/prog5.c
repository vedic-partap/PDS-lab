//VEDIC PARTAP 16CS10053 SECTION 5
//OPERATIONS 
#include<stdio.h>
#include<stdlib.h>

struct record  //STRUCT FOR RECORD 
{
  int roll;
  char name[20];
  int age;
};
struct node   //STRUCT FOR THE LIST
{
  struct record data;
  struct node * next;
}*header;
struct node * createList(int n)  //FUNCTION TO CREATE THE LIST
{
  struct node *header,*temp,*new;
  new=(struct node *)malloc(sizeof(struct node));
  printf("Enter the roll no of student: ");
      scanf("%d",&new->data.roll);
      getchar();
      printf("Enter the name of the student :");
      scanf("%[^\n]%*c",new->data.name);
      printf("Enter the age of the student : ");
      scanf("%d",&new->data.age);
      new->next=NULL;
      header=new;
      temp=new;
      int i;
      for(i=1;i<n;i++)
	{
	  new=(struct node *)malloc(sizeof(struct node));
	  printf("Enter the roll no of student: ");
	  scanf("%d",&new->data.roll);
	  getchar();
	  printf("Enter the name of the student:");
	  scanf("%[^\n]%*c",new->data.name);
	  printf("Enter the age of the student : ");
	  scanf("%d",&new->data.age);
	  new->next=NULL;
	  temp->next=new;
	  temp=new;
	}
      return header;
}
void insertion(int pos)   //FUNCTION TO INSERT
{
  struct node *new;
  new=(struct node *)malloc(sizeof(struct node));
  printf("Enter the roll no of student: ");
      scanf("%d",&new->data.roll);
      getchar();
      printf("Enter the name of the student :");
      scanf("%[^\n]%*c",new->data.name);
      printf("Enter the age of the student : ");
      scanf("%d",&new->data.age);
      new->next=NULL;

      if(pos==0)  //INSERTION AT BEGINING
    {
      new->next=header;
      header=new;
      return;
    }
      else if(pos==-1)  //INSERTION AT END
    {
      struct node *temp;
      temp=header;
      for(int i=2;temp->next!=NULL;i++)
	temp=temp->next;
      temp->next=new;
      return;
    }
      else           //AT ANY POSITION
    { 
      struct node *temp;
      temp=header;
      for(int i=2;i<pos;i++)
	{
	  
	  if(temp->next==NULL)
	    {
	      temp->next=new;
	      return;
	      
	    }
	  else
	    {
	      temp=temp->next;
	      
	    }
	}
      new->next=temp->next;
      temp->next=new;
      return;

    }
  
}
void deletion(int pos)  //DELETION FUNCTION
{
  if(header==NULL)
    {
      printf("There is no element ot delete\n");
      return;
    }
  else
    {
      if(pos==0)  //DELETION AT BEGINING 
	{
	  header=header->next;
	  return;
	}
      else if(pos ==-1)  //DELETION AT END
	{
	  struct node *temp;
	  temp=header;
	  for(int i=2;temp->next->next!=NULL;i++)
	    temp=temp->next;
	  temp->next=NULL;
	}
      else
	{
	 struct node *temp;
      temp=header;
      for(int i=2;i<pos && temp->next->next!=NULL;i++)
	{
	  
	  if(temp->next->next==NULL)
	    {
	      temp->next=NULL;
	      
	    }
	  else  //AT ANY POSITION
	    {
	      temp=temp->next;
	      
	    }
	}
     
      temp->next=temp->next->next; 
	}
    }
}
void print_list(struct node * header)  //FUNCTION TO PRINT THE LIST 
{
  struct node *temp;
  temp=header;
  printf("Student[1] = %d %s %d\n",temp->data.roll,temp->data.name,temp->data.age);
  int i;
  for(i=1;temp->next!=NULL;i++)
    {
      temp=temp->next;
      printf("Student[%d]= %d %s %d\n",i+1,temp->data.roll,temp->data.name,temp->data.age);
    }
  return ;
}
void print_reverse()  //FUNCTION TO PRINT IN REVERSE ORDER 
{
  struct node *t  =header;
  int g=1;
  struct node*temp;
  while(t->next !=NULL)
    {
      
      
      temp=t;
      int i;
      for(i=0;temp->next->next!=NULL;i++)
	{
	  temp=temp->next;
	}
      printf("Student[%d] = %d %s %d\n",g,temp->next->data.roll,temp->next->data.name,temp->next->data.age);
      temp->next=NULL;
      g++;
    }
   printf("Student[%d] = %d %s %d\n",g,temp->next->data.roll,temp->next->data.name,temp->next->data.age);
}
struct node *header=NULL;
int main()
{
  int n;
  printf("Give the value of the number of student : ");
  scanf("%d",&n);
  
  header=createList(n);
  print_list(header);
  printf("Enter the position to be deleted (pos=0 --begining ,-1--ending ) : ");
  int pos;
  scanf("%d",&pos);
  deletion(pos);
  printf("The list after deletion is : \n");
  print_list(header);
  printf("Enter the poistion at which node to be inserted : ");
  scanf("%d",&pos);
  insertion(pos);
  printf("The list after insertion is : \n");
  print_list(header);
  //print_reverse();

  return 0;
}
