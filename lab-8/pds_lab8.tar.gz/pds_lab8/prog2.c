//VEDIC PARTAP  16CS10053 SECTION 5
//SORTING ACCORDING TO DIFFERENT VALUES---ENTER THE NAES IN SMALL LETTERS
#include<stdio.h>
#include<stdlib.h>
struct record
{
  int roll;
  char name[20];
  int age;
};
void roll_sort(struct record a[],int n)  //FUNCTION TO SORT ACCORDING TO THE ROLL NO
{
  int count=1,i,j;
  while(count!=0)
    {
      count=0;
      for(i=1;i<n;i++)
	{
	  if(a[i].roll<a[i-1].roll)
	    {
	      struct record temp;
	      temp=a[i];
	      a[i]=a[i-1];
	      a[i-1]=temp;
	      count++;
	    }
	}
    }
}

void age_sort(struct record a[],int n) //SORT ACCORDING TO THE AGE
{
  int count=1,i,j;
  while(count!=0)
    {
      count=0;
      for(i=1;i<n;i++)
	{
	  if(a[i].age<a[i-1].age)
	    {
	      struct record temp;
	      temp=a[i];
	      a[i]=a[i-1];
	      a[i-1]=temp;
	      count++;
	    }
	}
    }
}
int string_compare(char a[],char b[]) //FUNCTION TO COMPARE THE STRING
{
  int i;
  for(i=0;a[i]!='\0'|| b[i]!='\0';i++)
    {
      if(a[i]>b[i])
	return 0;
      if(a[i]<b[i])
	 return 1;
    }
      return 0;
}
void name_sort(struct record a[],int n) //SORT ACCORDING TO THE NAME
{
  int count=1,i,j;
  while(count!=0)
    {
      count=0;
      for(i=1;i<n;i++)
	{
	  if(string_compare(a[i].name,a[i-1].name))
	    {
	      struct record  temp=a[i];
	      a[i]=a[i-1];
	      a[i-1]=temp;
	      count++;
	    }
	}
    }
}
int main()
{
  int n;
  printf("Give the number of the student : ");
  scanf("%d",&n);
  struct record a[n];
  int i;
  for(i=0;i<n;i++)
    {
      printf("Enter the roll no of student %d : ",i+1);
      scanf("%d",&a[i].roll);
      getchar();
      printf("Enter the name of the student %d :",i+1);
      scanf("%[^\n]%*c",&a[i].name);
      printf("Enter the age of the student %d : ",i+1);
      scanf("%d",&a[i].age);
    }
  printf("The output is :\n");
  int j;
  for(j=0;j<n;j++)
  {
    printf("Student[%d] = %d %s %d\n",j+1,a[j].roll,a[j].name,a[j].age);//USING DIFFERENT SORT FUNCTION IN MAIN
  }
  printf("Printing by sorting by roll number\n");
  roll_sort(a,n);
  for(j=0;j<n;j++)
  {
    printf("Student[%d] = %d %s %d\n",j+1,a[j].roll,a[j].name,a[j].age);
  }
printf("Printing by sorting by age\n");
  age_sort(a,n);
  for(j=0;j<n;j++)
  {
    printf("Student[%d] = %d %s %d\n",j+1,a[j].roll,a[j].name,a[j].age);
  }
printf("Printing by sorting by name\n");
  name_sort(a,n);
  for(j=0;j<n;j++)
  {
    printf("Student[%d] = %d %s %d\n",j+1,a[j].roll,a[j].name,a[j].age);
  }
  return 0; 
}
