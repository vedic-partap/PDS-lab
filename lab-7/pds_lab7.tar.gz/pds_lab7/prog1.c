//VEDIC PARTAP 16CS 10053 SECTION 5
//FINDING THE COMMON FACTORS
#include<stdio.h>
#include<stdlib.h>
int* factor_compute(int * a)//factor_compute FUNCTION
{
  int *fact;
  int n=*a;
  int cnt=0;
  fact=(int*)malloc(n*sizeof(int)); //ALLOCATING THE MEMORY
	      for(int i=0;i<n;i++)
		*(fact+i)=0;
   for(int i=1;i<=n;i++)
   {
     if(n%i==0)   
       {
	 *(fact+cnt)=i;
	 cnt++;
       }
   }
   return fact;   //RETURNING THE FACT POINTER
} 
int main()
{
  int n;
  printf("Give the number of elements " );
  scanf("%d",&n);
  int**a,*b;//ARRAY TO STORE THE FACTORS AND THE VALUE OF THE NUMBERS
  a=(int **)malloc(n*sizeof(int *));
  b=(int *)malloc(n*sizeof(int));
  for(int i=0;i<n;i++)
    {
      printf("Give element : ");
      int x;
      scanf("%d",&x);
      *(b+i)=x;
      *(a+i)=factor_compute(&x);
    }
  printf("The common factors of the elements are : \n");
  for(int i=0;i<*b;i++)
    {
      int q=*(*(a)+i);
      int flag=0;
      for(int j=1;j<n;j++)
	{
	  for(int k=0;k<*(b+j);k++)
	    {
	      if(*(*(a+j)+k)==q && q!=0)
		{
		flag++;
		break;
		}
	      
	    }
	}
      if(flag==n-1)
	printf("%d ",q);
    }
  printf("\n");
  return 0;
}
