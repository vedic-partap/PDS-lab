//VEDIC PARTAP 16CS10053 SECTION 5
//MERGING THE TWO SORTED ARRAY USING RECURSION
#include<stdio.h>
#include<stdlib.h>

void merge_recursion(int *a,int*b,int*c,int n,int m)//MERGE FUNCTION -USING RECURSION
{
 
  if(n==0)                           //BASE CASE
    {
      for(int i=0;i<m;i++)
	*(c+i)=*(b+i);
      return ;
    }
  if(m==0)
    {
     for(int i=0;i<n;i++)
	*(c+i)=*(a+i);
      return ;
    }
    if(*(a)<*(b))
      {
	*(c)=*(a);
	merge_recursion(a+1,b,c+1,n-1,m);//RECURSIVE CALLING OF THE MERGE FUNCTION
      }
    else
      {
	*(c)=*(b);
	merge_recursion(a,b+1,c+1,n,m-1); 
      }
}
int main()
    {
      int n,m;
      int*a,*b;                                    //DECLARING THE SORTED ARRAY
      printf("Give the size of the sorted array : ");     
      scanf("%d",&n);
      a=(int *)malloc(n*sizeof(int));                               //ALLOCATING THE MEMORY TO SORTED ARRAY
      printf("Give the elements of the first sorted array : ");
      for(int i=0;i<n;i++)
	scanf("%d",a+i);
      printf("Give the size of the another sorted array : ");
      scanf("%d",&m);
      b=(int *)malloc(m*sizeof(int));
      printf("Give the elements of the first sorted array : ");
      for(int i=0;i<m;i++)
	scanf("%d",b+i);
      
      int*c;                                                     //ARRAY TO STORE THE MERGED ARRAY
  c=(int *)malloc((n+m)*sizeof(int));
  merge_recursion(a,b,c,n,m);                                   //CALLING THE MEGE_RECURSION
      printf("The merged array is : ");
       	for(int i=0;i<n+m;i++)
       	  printf("%d ",*(c+i));
     printf("\n");
    return 0;

    }
