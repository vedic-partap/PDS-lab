//VEDIC PARTAP 16CS 10053 SECTION-5
//MERGING THE ARRAY USING POINTERS
#include<stdio.h>
#include<stdlib.h>
int *merge(int *a,int*b,int n,int m) //MERGE FUNCTION FOR MERGING THE TWO SOPRTED ARRAY
{
  int*c;
  c=(int *)malloc((n+m)*sizeof(int));//ALLOCATING THE MEMORY
	    int k=0,l=0;
  for(int i=0;i<n+m;i++)
  {
    
    if((*(a+k)<*(b+l))&& k<n || l>=m)
      {
	*(c+i)=*(a+k);
	k++;
      }
    else if((*(a+k)>=*(b+l))&& l<m || k>=n)
      {
	*(c+i)=*(b+l);
	l++;
      }

  }
	    return c;
}
int main()
    {
      int n,m;
      int*a,*b;//declaring the two sorted array
      printf("Give the size of the sorted array : ");
      scanf("%d",&n);
      a=(int *)malloc(n*sizeof(int));                             //allocating the memory
      printf("Give the elements of the first sorted array : ");
      for(int i=0;i<n;i++)
	scanf("%d",a+i);                                         //accepting the first sorted array
      printf("Give the size of the another sorted array : ");
      scanf("%d",&m);
      b=(int *)malloc(m*sizeof(int));             
      printf("Give the elements of the first sorted array : ");
      for(int i=0;i<m;i++)
	scanf("%d",b+i);
      int *c=merge(a,b,n,m);                                    //calling the merge function
      printf("The merged array is : ");
       	for(int i=0;i<n+m;i++)
       	  printf("%d ",*(c+i));
     printf("\n");
    return 0;

    }
