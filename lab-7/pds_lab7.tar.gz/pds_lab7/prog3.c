//VEDIC PARTAP 16CS10053 SECTION 5
//ADDING AND MULTIPLYING THE MATRICES

#include<stdio.h>
#include<stdlib.h>  //FOR USING malloc FUNCTION
int** add(int **a,int **b,int n,int m)  //FUNCTION TO ADD THE MATRICES A,B
{
  int **c; 
  c=(int**)malloc(m*sizeof(int *));//ALLOCATING THE MEMORY TO ARRAY OF POINTERS -TO MAKE 2-D MATRIXES
  for(int i=0;i<m;i++)
    {
      *(c+i)= (int *)malloc(n*sizeof(int));
    }
  for(int i=0;i<n;i++)
    {
      for(int j=0;j<m;j++)
	{
	  *(*(c+j)+i)=*(*(a+j)+i)+*(*(b+j)+i);//ADDING THE MATRIXES 
	}
    }
  return c; //RETURING THE ADDIED MATRICES

}
int** mul(int**a,int **b,int n,int m,int p,int q) //FUNCTION TO MULTIPLY THE MATRICES
{
  int **c;
  c=(int**)malloc(q*sizeof(int *));  //ALLOCATING THE MEMORY TO MATRICES
  for(int i=0;i<m;i++)
    {
      *(c+i)= (int *)malloc(n*sizeof(int));
    }
  
  if(m==p)  
    {                    
      for(int i=0;i<n;i++)     //MULTIPLYING THE MATRICES
	{
	  for(int j=0;j<q;j++)
	    {
	      *(*(c+j)+i)=0;
	      for(int k=0;k<m;k++)
		{
		  *(*(c+j)+i)+=*(*(a+k)+i)**(*(b+j)+k);
		}
	    }
	}
      return c;
    }
}
int main()
{
  int **a,**b;
  int n,m,p,q;
  printf("Give the size of the matrix A : ");//ACCEPTING THE SIZE OF THE MATRICES  A
  scanf("%d %d",&n,&m);
  printf("Give the size of the matrix B : ");//ACCEPTING THE SIZE OF THE MATRICES B
  scanf("%d %d",&p,&q);

  a=(int**)malloc(m*sizeof(int *));//ALLOCATING THE MEMEORY TO MATRIX A
  for(int i=0;i<m;i++)
    {
      *(a+i)=(int *)malloc(n*sizeof(int));
    }
  b=(int**)malloc(q*sizeof(int *));//ALLOCATING THE MEMORY TO MATRIX B
  for(int i=0;i<q;i++)
    {
      *(b+i)=(int *)malloc(p*sizeof(int));
    }
  printf("Give the elements of matrix A\n");
  for(int i=0;i<n;i++)
    {
      for(int j=0;j<m;j++)
	{
	  scanf("%d",*(a+j)+i);
	}
    }
printf("Give the elements of matrix B\n");
  for(int i=0;i<p;i++)
    {
      for(int j=0;j<q;j++)
	{
	  scanf("%d",*(b+j)+i);
	}
    }
  if(n!=p && m!=q)//CONDITION OT CHECK IF MATRIX CAN BE ADDED OR NOT
    {
      printf("The matrices can't be added\n");
    }
  else
    {
      printf("The addition of the matrix A nd B is\n");
      int **c;
      c=add(a,b,n,m);//CALLING THE ADDING FUNCTION
      for(int i=0;i<n;i++)
    {
      for(int j=0;j<m;j++)
	{
	  printf("%d ",*(*(c+j)+i));
	}
      printf("\n");
    }
    }
  if(m!=p)
    {
      printf("The matrices can't be multiplied\n");
      return 0;
    }
  else
    {
      printf("The multiplication of the matrices is \n");
      int ** mm;
      mm=mul(a,b,n,m,p,q);    //CALLING THE MULTIPLY FUNCTION
      for(int i=0;i<n;i++)
    {
      for(int j=0;j<q;j++)
	{
	  printf("%d ",*(*(mm+j)+i));
	}
      printf("\n");
    }
    }

    
  return 0;

}
