//VEDIC PARTAP 16CS 10053 SECTION 5
//CHECKING PALINDRONME OR NOT

#include<stdio.h>
#include<stdlib.h>
char * enter_text(char*s)//FUNCTION TO GET THE STRING 
  {
    char* d;
    d=(char*)(malloc(30*sizeof(char)));   //ALLOCATING THE MEMORY 
      scanf("%[^\n]%*c",d);
    return d;
  }
int string_length(char* s)//FUNCTION TO FING THE LENGTH OF THE STRING
    {
      int counter=0;
      for(int i=0;i<30;i++)
	{
	  if(*(s+i)!='\0')
	    counter++;
         if(*(s+i)=='\0')
	break;
	  
	}
      
      return counter;
    }
char*reverse(char*s)//FUNCVTIUON TO FIND THE REVERSE OF THE STRING 
{
  char *d;
  int n=string_length(s);
  d=(char*)(malloc(30*sizeof(char)));//ALLOCATING THE MEMORY
  for( int i=0;i<n;i++)
   {
     *(d+i)=*(s+n-1-i);//REVERSING THE STRING
   }
  return d;
}

int main()
{
  char *s;//DECLARING THE STRING
  s=enter_text(s);
  printf("The string is %s\n",s);
  int len=string_length(s);
  printf("The size of the array is %d\n",len);
  char*rever;
  rever=reverse(s);
  printf("The reverse of the string is %s\n",rever);
  for(int i=0;i<len;i++)
    {
      if(*(s+i)!=*(rever+i)) //CHECKING IF THE STRING IS EQUAL TO IT'S REVERSE OR NOT
	{
	  printf("The string is not palindrome\n");
	  return 0;
	}
    }
      printf("The string is palindrome\n");
  return 0;
}
