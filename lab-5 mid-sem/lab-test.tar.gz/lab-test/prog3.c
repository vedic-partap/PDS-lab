//Vedic Partap  16CS10053 Section 5
//PRINT ALL POSSIBLE SUB-STRING

#include<stdio.h>
int main()
{
  char a[20];
  printf("Give a string (maximum length is 20) : ");//ACCEPTING AN STRING 
  scanf("%s",a);
  printf("Input :  %s\n" ,a);
  printf("Output  : \n");
  int i;
  for(i=0;a[i]!='\0';i++);//FINDING THE LENGTH OF THE STRING
  int len=i;
  int j,k,l;
  for(i=1;i<=len;i++)            //PRINTING THA SUB-STRING IN GIVEN MANNER
    {
      for(j=0;j<=len-i;j++)
	{
	  for(k=0;k<i;k++)
	    {
	      printf("%c",a[j+k]);
	    }
	  for(l=1;l<=len-i;l++)
	    {
	      printf(" ");
	    }
	}
      printf("\n");
    }
  return 0;
}
