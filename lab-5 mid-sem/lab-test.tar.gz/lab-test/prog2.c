//VEDIC PARTAP 16CS10053 SECTION 5

//MAXIMUM ELEMENT AND IT'S POSITION 

/*
VARIABLES IN main 
n-number of elements
a[]-array
max_e-maximun element
pos-position of maximum element  ,
*/
#include<stdio.h>
float max_element(float a[],int n)                  //FUNCTION FOR FINDING THE MAXIMUM ELEMENT IN ARRAY
{
  int i;
  float max_e=a[0];                                //DECLARING THE MAXIMUN ELEMENT AND ARBITARLY ASSIGNING IT TO A[O]
  for(i=0;i<n;i++)
    {
      if(a[i]>max_e)                             //COMPARING THE UPTO MAX.VALUE TO THE ELEMENTS
	max_e=a[i];
    }
  return max_e;                                 //RETURNING THE MAXIMUM ELEMENT
}   


int position(float a[],int n)                   //FUNCTION FOR FINDING TGHE POSITION OF THE MAXIMUM ELEMENT
{
  float max=max_element(a,n);                    //FINDING THE MAXIMUM ELEMENT BY THE ABOVE FUNCTION
  int i;
  for(i=0;i<n;i++)
    {
      if(a[i]==max)
	return i;
    }
}
int main()                    //MAIN FUNCTION
{
  int n;
  printf("Give the size of the array : "); 
  scanf("%d",&n);                                //ACCEPTING THE ARRAY
  int i;
  float a[n];
  for(i=0;i<n;i++)
    {
      printf("Give a number : ");
      scanf("%f",&a[i]);
    }
  float max_e=max_element(a,n);
  int pos=position(a,n);
  printf("N=%d ; array = a[] \nmax_array = %f \nposition of max_array = %i",n,max_e,pos);
  printf("\nThe input array is : \n");


  for(i=0;i<n;i++)                           //PRINTING THE INPUT ARRAY
    printf("%f ",a[i]);


  printf("\nThe output array is : \n");  
  for(i=pos;i<n-1;i++)                          //CHANGING THE ARRAY TO DESIRED FORMAT
    {
      
      a[i]=a[i+1];       
    }
  a[n-1]=max_e;


  for(i=0;i<n;i++)                           //PRINTING THE output ARRAY-FORMATTED ARRAY
    printf("%f ",a[i]);
  printf("\n");	 
 
		   return 0;
}
