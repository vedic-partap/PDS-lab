//VEDIC PARTAP 16CS10053 SECTION 5

//FINDING THE TIME AFTER WHICH THE DIFFERENCE BETWEEN THE AMOUNTER AOMPUNDED ANNUALLY AMD MONTHLY IS SOME GIVEN VALUE
//ASSUMING THAT THE INTERSET COMPUNDED ANNUALLY IS ADDED TO ACCOUNT AFTER THE END OF THE YEAR AND INTEREST COMPUNDED MONTHLY IS ADDED AFTER TRHE END OF EACH MONTH


//VARIABLES :
/*
P--PRINCIPLE AMOUNT
r-INTEREST  
diff- the difference required-GIVEN VALUE IS 25 %
i_m-interest added  monthly ,c_m-total amount (monthly)  ,i_a -interest added annually ,c_a - total amount annually
*/
#include<stdio.h>
int main()
{
  float p,r;
  printf("Enter the principle : ");
  scanf("%f",&p);                                         // ACCEPTING THE PRINCIPLE AMOUNT AND THE INTERST

 printf("Enter the annual interest : ");
  scanf("%f",&r);
  float diff=p/4;
 printf("Enter the difference required (in percentage eg.25) : ");
  scanf("%f",&diff);
  diff=diff/100*p;
  int i;
  float c_a=p,c_m=p;

  float i_a=0,i_m=0;
  float c_a_p=p;
  for(i=1;i<1000;i++)                                     //ITERATING THROUGH MONTHS
    {
      i_m=(float)c_m*r/12.00/100.00;                      //CALCULATING INTEREST COMPUNDED MONTHLY
      c_m=c_m+i_m;
      
      if(i%12==0)                                         //AS EACH YEAR GOES THE AMOUNT CALCULATED ANNUALLY IS INCREASED
	{
	  i_a=c_a*r/100;
	  c_a=c_a+i_a;
	  
	}
      if((c_m>=c_a && c_m-c_a>=diff) || (c_m<=c_a && c_a-c_m>=diff))
	{
	  printf("After the %d months \nTotal amount compunded annually is %f\nThe total amount compunded monthly is %f \n",i,c_a,c_m);
	  break;
	  }
      
    }
  return 0;

}
