//VEDIC PARTAP  16CS10053  SECTION 5
//CREATING THE FILE 
#include<stdio.h>
typedef struct record   //STRUCTURE FOR THE DATA 
{
  char emp_name[20];
  int emp_no;
  int emp_age;
  int emp_sal;
}data;
typedef struct newrecord  //STRUCTURE FOR THE OLD DATA 
{
  char emp_name[20];
  int emp_no;
  int emp_age;
  int emp_sal;
  int emp_annual;
}newdata;
int main()
{
  FILE  *f1;
  f1=fopen("f1","w");  //OPENING THE FILE IN WRITE MODE 
  int n;
  printf("Give the number of employees ; "); //ACCEPTING THE NO OF EMPLOYEES 
  scanf("%d",&n);
  int i;
  for(int i=0;i<n;i++)
    {
      data d;   //DECLARING THE STRUCT 
      printf("Give the emp name : ");   //ACCEPTING THE DATA
      scanf("%s",d.emp_name);
      getchar();
      printf("Give the emp no : ");
      scanf("%d",&d.emp_no);
      printf("Give the emp age : ");
      scanf("%d",&d.emp_age);
      printf("Give the emp salary : ");
      scanf("%d",&d.emp_sal);
      fprintf(f1,"%s %d %d %d",d.emp_name,d.emp_no,d.emp_age,d.emp_sal);//PRINTING THE DATA TO FILE 
      
    }
  fclose(f1);//CLOSING THE FILE 
  f1=fopen("f1","r");//OPENING THE FILE IN THE READ MODE 
  FILE *f2;
  f2=fopen("f2","w");//OPENING THE FILE IN THE THE WRITE MODE 
  printf("\nThe original data is----------- :\n");
  for(i=0;i<n;i++)//PRINTING THE ORIGINAL DATA IN THE THE STANDARD OUTPUT 
    {newdata d;
      fscanf(f1,"%s %d %d %d",d.emp_name,&d.emp_no,&d.emp_age,&d.emp_sal);
      printf("\nName -   %s\n",d.emp_name);
      printf("Empl no is   %d\n",d.emp_no);
      printf("Emp age is   %d\n",d.emp_age);
      printf("Emp salary is   %d\n",d.emp_sal);   
      fprintf(f2,"%s %d %d %d %d",d.emp_name,d.emp_no,d.emp_age,d.emp_sal,12*d.emp_sal);

    }
  fclose(f2);
  f2=fopen("f2","r");
  
  printf("\nThe final data is ------------:\n");//PRINTING THE FINAl DATA 
   for(i=0;i<n;i++)
    {
      newdata d;
      fscanf(f2,"%s %d %d %d %d",d.emp_name,&d.emp_no,&d.emp_age,&d.emp_sal,&d.emp_annual);
      printf("\nName -   %s\n",d.emp_name);
      printf("Empl no is   %d\n",d.emp_no);
      printf("Emp age is   %d\n",d.emp_age);
      printf("Emp salary is   %d\n",d.emp_sal);  
      printf("Emp annual salary   %d\n",12*d.emp_sal); 
    }
   return 0;
}
