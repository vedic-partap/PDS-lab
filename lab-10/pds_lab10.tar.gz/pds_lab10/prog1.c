//VEDIC PARTAP 16CS 100053 SECTION 5
//MATCHING PARENTHESES 

#include<stdio.h>
#define MAX 100  //DEFINGING THE MAXIMUM SIZE OF THE ARRAY
typedef struct stk{   //STRUCTURE OF THE STACK WITH TYPEDEF
  char data[MAX];
  int top;
} stack;
stack s;
void create()  //FUNCTION TO CREATE THE STACK 
{
  s.top=-1;   
}
void push(char c)  //FUNCTION TO PUSH TO STACK
{
  if(s.top==MAX-1)
    {
      printf("Stack Overflow\n");
      return ;
    }
  else
    {
      s.top++;
      s.data[s.top]=c;
    }
  return ;
}
char pop()  //FUNCTION TO POP THE ELEMENT 
{
  if(s.top==-1)
    {
      printf("The stack is empty\n");
      return 'e';
    }
  else
    {
      char c=s.data[s.top];
      s.top--;
      return 'e';
    }
}
char topEl()   //FUNCTION TO GET THE TOP ELEMENT IN STACK
{
  if(s.top==-1)
    {
      printf("The stack is empty\n");
      return 'e';
    }
  else
    {
      return s.data[s.top];
    }
}
int isEmpty()  //CHECKING THE EMPTYNESS OF THE STACK
{
  if(s.top==-1)
    return 1;
  else
    return 0;
}
int main()
{
  char c[100];
  printf("Give a mathematical expression : "); //GETTING THE EXPRESSION 
  scanf("%s",c);
  int i;
  for(i=0;c[i]!='\0';i++) 
    {
      if(c[i]=='{' || c[i]=='[' || c[i]=='(')  //PUSHING THE OPEN PARENTHESES  AND CHECKING WITH THE CLOSED PARENTHESES
	{
	  push(c[i]);
	}
      else if(c[i]==')')
	{
	  if(topEl()=='(')
	    {
	      pop();
	    }
	  else
	    {
	      printf("The expression is not correctly parrenesized\n");
	      return 0;
	    }
	}
      else if(c[i]==']')
	{
	  if(topEl()=='[')
	    {
	      pop();
	    }
	  else
	    {
	      printf("The expression is not correctly parrenesized\n");
	      return 0;
	    }
	}
      else if(c[i]=='}')
	{
	  if(topEl()=='{')
	    {
	      pop();
	    }
	  else
	    {
	      printf("The expression is not correctly parrenesized\n");
	      return 0;
	    }
	}
      
    }
  pop();
  //printf("%c\n",s.top);
  if(isEmpty())  //CHECKING IF THE STACK IS EMPTY OR NOT AT LAST
	{
	  printf("The expression is correctly parrenesized\n");
	}
      else
	printf("The expression is not correctly parrenesized\n");
  return 0;
}
