//VEDIC PARTAP  SECTION -5 16CS10053
//EVEN AND ODD FILE 

#include<stdio.h>
int main()
{ 
  int n;
  FILE *ftr;                         //POINTER TO THE FILE 
  ftr=fopen("ftr","w");
  printf("Give the value of n : ");//ACCEPTING THE VALUE
  scanf("%d",&n);
  int i;
  for(i=0;i<n;i++)
    {
      int x;
      printf("Give a number : ");
      scanf("%d",&x);
      fprintf(ftr,"%d ",x);   //PRINTING TO THE FILE 
    }
  int m;
  printf("Give the value of m : ");//ACCEPTING NEXT M NUMBERS 
  scanf("%d",&m); 
  for(i=0;i<m;i++)
    {
      int x;
      printf("Give a number : ");
      scanf("%d",&x);
      fprintf(ftr,"%d ",x);   //PRINTING TO THE FILE 
    }
  fclose(ftr);
  ftr=fopen("ftr","r");
  FILE *evenfile,*oddfile;
  evenfile=fopen("evenfile","w");   //OPEN FILE IN WRITE MODE -EVENFILE
  oddfile=fopen("oddfile","w");     //OPEN FILE IN WRITE MODE -ODDFILE
  for(i=0;i<n+m;i++)
    {
      int x;
      fscanf(ftr,"%d",&x);
      if(x%2==0)                     //CHECKING ODD AND EVEN
	{
	  fprintf(evenfile,"%d ",x);
	}
      else
	fprintf(oddfile,"%d ",x);

    } 
  fclose(evenfile);          //CLOSING THE FILE 
  fclose(oddfile);
  evenfile=fopen("evenfile","r");
  oddfile=fopen("oddfile","r");
  int z;
  printf("The numbers from the even file are\n");
  while(fscanf(evenfile,"%d ",&z)!=EOF)             //PRINTING TO STANDARD OUTPUT 
    {
      printf("%d ",z);
    }
  printf("\nThe numbers from the oddfile are \n");
  while(fscanf(oddfile,"%d ",&z)!=EOF)
    {
      printf("%d ",z);
    }
  printf("\n");
  return 0;
}
