//VEDIC PARTAP  16CS10053  SECTION-5 
//CHECKING THE PALINDROME OR NOT 
#include<stdio.h>
#define MAX 100
typedef struct stk{   //STRUCTURE OF THE STACK
  char data[MAX];
  int top;
} stack;
stack s;
void create()     //FUNCTION TO CREATE THE STACK 
{
  s.top=-1;
}
void push(char c)  //FUNCTION TO PUSH THE ELEMENT IN THE STACK
{
  if(s.top==MAX-1)  
    {
      printf("Stack Overflow\n");
      return ;
    }
  else
    {
      s.top++;
      s.data[s.top]=c;
    }
  return ;
}
char pop()   //FUNCTION TO POP THE ELEMENT 
{
  if(s.top==-1)
    {
      printf("The stack is empty\n");
      return 'e';
    }
  else
    {
      char c=s.data[s.top];
      s.top--;
      return 'e';
    }
} 
char topEl()  //FUNCTION TO GET THE TOP ELEMENT OF THE STACK 
 {
  if(s.top==-1)
    {
      printf("The stack is empty\n");
      return 'e';
    }
  else
    {
      return s.data[s.top];
    }
}
int isEmpty()
{
  if(s.top==-1)
    return 1;
  else
    return 0;
}
int main()
{
  char c[100];    //STRING TO GET THE STRING 
  printf("Give a string : ");
  scanf("%[^\n]%*c",c);  //ACCEPTING THE STRING 
  int i=0;
  for(i=0;c[i]!='\0';i++)
    {
      push(c[i]);   //PUSHING THE ELEMENT TO THE STACK  
    }
    for(i=0;!isEmpty();i++)
    {
      char x=topEl();
 
      if(x!=c[i])
	{
	  printf("The string is not palindrome\n"); //POPING THE ELEMENT AND CHECK WITH THE ORIGINAL ONE 
	  return 0;
	}
      pop();
    }
  printf("The string is palindrome\n");
  return 0;

}
