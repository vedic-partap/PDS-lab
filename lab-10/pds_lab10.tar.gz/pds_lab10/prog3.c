//VEDIC PARTAP  16CS 10053 SECTION 5 
//FORMING THE QUEUE FOR THE EVEN AND THE ODD 

#include<stdio.h>
#define MAX 100
typedef struct que{  //structure for the queue 
  int data[MAX]; //storing the data 
  int fwd,rear; //forward and the rear index 
}queue;
queue q,q1; 
void create(queue q)  //function for the creation of the queue 
{
  q.fwd=0;q.rear=-1;
}
void push(queue q,int n)  //function to push the element to queue 
{
  if(q.rear ==MAX-1)
    {
      printf("The queue is full\n");
	return;
    }
  else
    {
      q.rear++;
      q.data[q.rear]=n;
    }
}
int pop(queue q) //function to pop the element 
{
  if(q.rear-q.fwd==-1)
    {
      printf("The queue is empty\n");
      return -1000;
    }
  else
    {
      int n=q.data[q.fwd];
      q.fwd++;
      printf("&&%d\n",n);
      return n;
    }

}
int isEmpty(queue q)  //to check if the queue is empty 
{
  if(q.rear-q.fwd==-1)
    return 1;
  else
    return 0;
}
int topEl(queue q)
{
  if(q.rear-q.fwd==-1)
    {
      printf("The queue is empty\n");
      return -100;
    }
  else
    return q.data[q.fwd];
}
int main()
{

  int q_a[100],q_p[100],q_n[100];
  int start=0,end=-1;
  int start_positive=0,start_negative=0,end_positive=-1,end_negative=-1;
  int n,i;
  int u;long int temp;
  printf("Enter the number of elements : ");
  scanf("%d",&n);    //scanning the total number of elements
  for(i=0;i<n;i++)
  {
    printf("Give anumber : ");
        scanf("%d",&q_a[++end]);
  }
  printf("The current queue_all is : ");
  for(i=start;i<=end;i++)
  {
        printf("%d ",q_a[i]);   //printing the original entered queue
  }
  printf("\n");
  for(;start<=end;start++)   //separating in positive and negative
  {
        if(q_a[start]>=0)
        {
                q_p[++end_positive]=q_a[start];
        }
        else
        {
                q_n[++end_negative]=q_a[start];
        }
  }
  printf("The positve numbers are (from the positive queue ):- ");

  for(i=start_positive;i<=end_positive;i++)
  {
        printf("%d ",q_p[i]);   //printing the positive queue
  }
  printf("\n");
  printf("The neagtive numbers are(from the negative queue ) :- ");
  for(i=start_negative;i<=end_negative;i++)
  {
        printf("%d ",q_n[i]);   //printing the negative queue
  }
  printf("\n");
  return 0;
}
