//Vedic Partap 16CS10053 Section 5

//The year which is a multiple of 4 is a leap year 
//But the year multiple of 100 is not leap year but that of 400 is leap year

#include<stdio.h>
#include<math.h>
int main()
{
  int m[13]={0,3,3,6,1,4,6,2,5,0,3,5,1};//remainder of the total days upto month by seven in noirmal year
  int l[13]={0,3,4,0,2,5,0,3,6,1,4,6,2};//remainder of the total days upto month by seven in noirmal year

  char s[8];
  printf("Enter the date in format ddmmyyy : ");    //Excepting the date in the given format
  scanf("%s",&s);
  int i=0;
  for(i=0;i<8;i++)
    {
      s[i]=s[i]-'0';
    }
  int day=s[0]*10+s[1],month =s[2]*10+s[3],year=s[4]*1000+s[5]*100+s[6]*10+s[7];    // using the if -else condition printi9ng the corresponding to the number
  printf("The date is ");
  if(month==1)
  printf("%d January %d",day,year);
if(month==2)
  printf("%d Feb %d",day,year);
if(month==3)
  printf("%d March %d",day,year);
if(month==4)
  printf("%d April %d",day,year);
if(month==5)
  printf("%d May %d",day,year);
if(month==6)
  printf("%d June %d",day,year);
if(month==7)
  printf("%d July %d",day,year);
if(month==8)
  printf("%d August",day,year);
 if(month==9)
   printf("%d September ",day,year);
if(month==10)
  printf("%d Oct %d",day,year);
if(month==11)
  printf("%d Nonember %d",day,year);
if(month==12)
  printf("%d December %d",day,year);

  int counter=0;
  if(year-2017>=0)
    {
      
for(i=2018;i<year;i++)
  {
    if(i%4==0)
      {
	if(i%100==0)
	  {
	  if(i%400==0)
	    counter+=2;
	  else
	    counter++;
	  }
	else
	  counter+=2;	
      }
    else 
      counter++;
  }
 
    }
else
    {
      
for(i=2017;i>year;i--)
  {
    if(i%4==0)
      {
	if(i%100==0)
	  {
	  if(i%400==0)
	    counter-=2;
	  else
	    counter--;
	  }
	else
	  counter-=2;
	
      }
    else 
      counter--;
  }
 
    }
  counter=counter%7;
  if(year%4==0)
    {
      if(year%100==0)
	{
	  if(year%400)
	    {
 counter= counter+l[month-1];
 counter=counter%7; counter=counter+day-1; counter=counter%7;
 
	    }
	  else
	    {
                counter= counter+m[month-1];
 counter=counter%7; counter=counter+day-1; counter=counter%7;
 
	    }
	}
      else
	{
              counter= counter+l[month-1];
 counter=counter%7; counter=counter+day-1; counter=counter%7;
 
	}
    }
  else
    {
         counter= counter+m[month-1];
 counter=counter%7; counter=counter+day-1; counter=counter%7;
 
    }
  counter=(counter+7)%7;

  //Printing the day using if else condition

  if(counter==0)
    printf("\nThe day on this date is Sunday\n");
  if(counter==1)
    printf("\nThe day on this date is Monday\n");
  if(counter==2)
    printf("\nThe day on this date is Tuesday\n");
  if(counter==3)
    printf("\nThe day on this date is Wednesday\n");
  if(counter==4)
    printf("\nThe day on this date is Thursday\n");
  if(counter==5)
    printf("\nThe day on this date is Friday\n");
  if(counter==6)
    printf("\nThe day on this date is Saturday\n");
  

 return 0;

}
