//Vedic Partap 16Cs10053 Section 5

#include<stdio.h>
#include<math.h>
int main()
{
  float ax,ay,bx,by;
  printf("Give the co-ordinate of the first point ");
  scanf("%f %f",&ax,&ay);
printf("\nGive the co-ordinate of the second point ");
  scanf("%f %f",&bx,&by);
  float length=sqrt((ax-bx)*(ax-bx)+(ay-by)*(ay-by));
  float slope = (by-ay)/(bx-ax);
  float x=(ax+bx)/2;
  float y=(ay+by)/2;
  float slopepbs=-1/slope;
  printf("The length of the line segment is %f \nThe slope of the line Ab is %f \nThe X- co-ordinate 0f the mid point is %f \nThe Y-co-ordinate of the mid poiunt is %f \nThe slope of the perpendicular bisector is %f ",length,slope,x,y,slopepbs);
  printf("\nThe euation of the perpendicular trinagle is y=%fx + %f \n",slopepbs,y-slopepbs*x);
  return 0;

}
