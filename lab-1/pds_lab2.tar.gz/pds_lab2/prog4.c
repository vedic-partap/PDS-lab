//Vedic Partap 16cs100953 section 5

#include<stdio.h>
#include<math.h>
int main()
{
  float ax,ay,bx,by,cx,cy;
  printf("The the first co-ordinate ");
    scanf("%f %f",&ax,&ay);
    printf("\nThe the second co-ordinate ");
    scanf("%f %f",&bx,&by);
    printf("\nThe the third co-ordinate ");
    scanf("%f %f",&cx,&cy);
    float dab,dbc,dca;
    dab=sqrt((ax-bx)*(ax-bx)+(ay-by)*(ay-by));
    dbc=sqrt((cx-bx)*(cx-bx)+(cy-by)*(cy-by));
    dca=sqrt((ax-cx)*(ax-cx)+(ay-cy)*(ay-cy));
    printf("     %f %f %f",dab,dbc,dca);
    if(dab+dbc>dca && dab+dca>dbc && dbc+dca>dab)
      {
	printf("\nIts a valid Triangle\n");
	if(dca==dbc && dbc==dca)
	  printf("\nIts equilateral trinagle");
	else if(dab==dbc ||dab==dca ||dbc==dca)
	  printf("\n Its a isosceles trinagle");
         
	else
	  printf("\n its a scalane trinangle");
       if(dab*dab+dbc*dbc==dca*dca ||dab*dab+dca*dca==dbc*dbc ||dca*dca+dbc*dbc==dab*dab )
      printf("\nIts a right angle triangle\n");
      }
    else
      printf("Its not a valid triangle");

    
return 0;



}
