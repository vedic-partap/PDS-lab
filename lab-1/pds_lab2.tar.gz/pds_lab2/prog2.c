//Vedic Partap 16CS10053 Section 5
//Finding The roots the quadratic

#include<stdio.h>
#include<math.h>
int main ()
{  
  printf("Give the coefficient of the quadratic equations ");
  float a,b,c;
  scanf("%f %f %f",&a,&b,&c);
  float  d;
  d=b*b-4*a*c;
  if(d<0)
    {
      float D=-d;
      float realPart,imagPart;
      realPart=-b/(2*a);
      imagPart=sqrt(D)/(2*a);
      printf("\nThe roots are %f + i%f and %f - i%f\n",realPart,imagPart,realPart,imagPart); 
    }
  else
    {
      float s1,s2;
      s1=(-b+sqrt(d))/(4*a);
 s2=(-b-sqrt(d))/(4*a);
 printf("\nThe roots are %f %f\n",s1,s2);



    }

 
}
