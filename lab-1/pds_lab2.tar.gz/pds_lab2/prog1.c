//Vedic Partap 16CS10053 section 5
//using the precision 


#include<stdio.h>
int main()
{
  printf("Enter the number");
  float n;
  scanf("%f",&n);
  // float a =n + 0.05;
  printf("\nThe number rounded to first decimal number is %.1f \n",n);
  //float b= n+0.005;
  printf("The number rounded to second decimal number is %.2f\n",n);
  return 0;                                                                                                                                                                                                                               
}
