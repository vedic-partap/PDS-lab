//Vedic Partap    16CS10053   Secftion -5

#include<stdio.h>
#include<math.h>
int main()
{
  int n;
  printf("Enter the value of n : ");  
  scanf("%d",&n);
  float a[n];
  float sum=0;
  int i;
  for( i=0;i<n;i++)
    {
      printf("\nEnter the %d number : ",i+1);
      scanf("%f",&a[i]);
      sum+=a[i];
    }
  float mean=sum/n;                      //Finding the mean of the array by dividing the sum of the elements by n
  float sd=0;
  int j;
  for(j=0;j<n;j++)
    {
      sd+=(a[j]-mean)*(a[j]-mean);      //finding the Standard deviation of the numbers
    }
  sd=sd/n;
  sd=sqrt(sd);
  printf("\nThe standard deviation of the series is %f\n",sd);
  return 0;   

}
