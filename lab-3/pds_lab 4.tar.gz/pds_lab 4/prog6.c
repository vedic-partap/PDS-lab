//Vedic Partap   16CS10053  Section5
//Finding the kth largest element in the array

#include<stdio.h>
int main()
{
  int n;
  
  printf("Give the number of element in the array : ");
  scanf("%d",&n);                                             //Accepting the size of the array
  int a[n];
  int i;
  for(i=0;i<n;i++)
    {
      printf("Give a positive number : ");                 //Accepting the positive integers
      scanf("%d",&a[i]);
    }
  int k;
  printf("Give the value of x :");
  scanf("%d",&k);
 int max=a[1];
 for(int i=1;i<=k;i++)                                      //doing without sorting the array
    {
      max=0;
      int d=1;
      int j;
      for(j=0;j<n;j++)
	{
	    if(a[j]!=-1000000)
	    {
	      if(a[i]>max)
		{
		  max=a[i];
		  d=i; 
		}                            
	    }
	    
	}
      if(i!=k)
      a[d]=-1000000;
          }
  printf("The largest %d th element is %d\n",k,max); 
}
