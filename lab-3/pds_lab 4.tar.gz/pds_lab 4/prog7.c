#include<stdio.h>
int main()
{ 
  char a[300];
  printf("Give a string : ");
  scanf("%[^\n]%*c",&a);
  int i,counter=1;
  for(i=0;a[i]!='\0 ';i++)
    {
      if(a[i]=='\ ')
	counter++;
    }
  printf("Total number of words = %d",counter);
  int j; 
  for(int j=0;(a[j]!='\ '&& a[j-1]=='\ ')||j==0;j++)
    {int counter=0;
      int k;
      for(int k=1;(a[k]!='\ '&& a[k-1]=='\ ')||k==0;k++)
	{
	  if(a[j]==a[k])
	    {int y=1;
	      for(y=1;a[j+y]!='\ ';y++)
		{
		  if(a[j+y]==a[k+y])
		    {
		      if(a[j+y+1]=='\n')
			counter++;
		    }
		  else
		    break;
		}
	    }
	} 
      printf("The frequency are %d",counter);
    }

}
