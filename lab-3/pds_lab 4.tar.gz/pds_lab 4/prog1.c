//Vedic partap  16CS10053  Section-5
//Find that agiven number is present in the array
#include<stdio.h>
int main()
{
  int n;
  printf("Give the value of the n : ");                      //accepting the size of the array
  scanf("%d",&n);
  int a[n];
  printf("Give the value of the numbers in the array");
  int j;
  for(j=0;j<n;j++)                                         //loop for accepting the values in the array
    {
      scanf("%d",&a[j]);
    }
  int x;
  printf("\ngive the value of x ");
  scanf("%d",&x);
  int i;
  for(i=0;i<n;i++)
    {
      if(a[i]==x)                                        // checking the condition for the x in array
	{
	  printf("\n%d is present in the array at position %d\n",x,i);
        return 0;
	}
    }
  printf("\n%d is not present in the array\n",x+1);
  return 0;
  
}  
