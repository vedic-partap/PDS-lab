//Vedic Partap 16CS10053  section 5
//printing the array in reverse order

#include<stdio.h>
#include<string.h>
int main()
{
  char a[200];
  printf("Give a string ");
  scanf("%[^\n]%*c",&a);    //Accepting the array such that space is also aacepted and thse are stored in array of characters
  int i;
  printf("The input string is : "); //printing the array as input
  for(i=0;a[i]!='\0';i++)
    {
      printf("%c",a[i]);
    }
  printf("\n");
  printf("The output string is : ");//printing the array in the reverse order
  i=i--;
  for(;i>=0;i--)
    printf("%c",a[i]);
  printf("\n");
  return 0;
}
