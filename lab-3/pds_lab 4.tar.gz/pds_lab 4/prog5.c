//Vedic Partap  16Cs10053 Section 5
//printing the pattern

#include<stdio.h>
int main()
{
  int n;
  printf("Give the value of n ; ");
  scanf("%d",&n);
  if(n%2==0)                           //case for even value of n
    {
      int i;
      for(i =1;i<=n/2;i++)
	{
	  int j;
	  for(j=1;j<=(n/2-i);j++)
	    {
	      printf(" ");            //printing the spaces 
	    }
	  int k;
	  for(k=1;k<=2*i-1;k++)
	    {
	      printf("%d",k);     //printing the sequece of number
	    }
	  int z;
	   for(z=1;z<=(n/2-i);z++)
	    {
	      printf(" ");
	    }
	   printf("\n");
	}
	 int a;
      for(a =n/2;a>=1;a--)
	{
	  int b;
	  for(b=1;b<=(n/2-a);b++)
	    {
	      printf(" ");
	    }
	  int c;
	  for(c=1;c<=2*a-1;c++)
	    {
	      printf("%d",c);
	    }
	  int d;
	   for(d=1;d<=(n/2-i);d++)
	    {
	      printf(" ");
	    }   
	   printf("\n");
	}
    }
  if(n%2==1)                           //Case for odd value of n
    { 
      n=n-1;
      int i;
      for(i =1;i<=n/2;i++)
	{
	  int j;
	  for(j=1;j<=(n/2-i)+1;j++)
	    {
	      printf(" ");        //printing the spaces
	    }
	  int k;
	  for(k=1;k<=2*i-1;k++)
	    {
	      printf("%d",k);      //printing the sequence of the numbers
	    }
	  int z;
	   for(z=1;z<=(n/2-i)+1;z++)
	    {
	      printf(" ");
	    }
	   printf("\n");
	}
      int f;
      for(f=1;f<=n+1;f++)
	printf("%d",f);
      printf("\n");
	 int a;
      for(a =n/2;a>=1;a--)
	{
	  int b;
	  for(b=1;b<=(n/2-a)+1;b++)
	    {
	      printf(" ");
	    }
	  int c;
	  for(c=1;c<=2*a-1;c++)
	    {
	      printf("%d",c);
	    }
	  int d;
	   for(d=1;d<=(n/2-i)+1;d++)
	    {
	      printf(" ");
	    }   
	   printf("\n");
	}
    }
      return 0;

}
