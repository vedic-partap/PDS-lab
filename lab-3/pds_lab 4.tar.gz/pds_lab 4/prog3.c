//Vedic Partap   16CS10053  Section 5
//Finding the sub array whose sum is 0

#include<stdio.h>
int main()
{
  int n;
  int counter=0;
  int f_counter=0;
  printf("Enter the numbers in the array : ");              //Accepting the numbers in the array
  scanf("%d",&n);
  int a[n];
  int g;
  for(g=0;g<n;g++)                                         //Accepting the array
    {
      printf("\nGive a number : ");
      scanf("%d",&a[g]);
    }
int p=0;
  
  for(p=0;p<n;p++)
    {
      int q;
      int f_sum=a[p];
      for(q=p+1;q<n;q++)
	{
	  f_sum+=a[q];
	  if(f_sum==0)
	    {
	      f_counter++;                             //Finding the number of such sub arraies whose sum is 0
	     
	    }
	}
    }
   printf("\nNumber of possible sub-arrays = %d\n",f_counter);
  int i=0;
  
  for(i=0;i<n;i++)
    {
      int j;
      int sum=a[i];
      for(j=i+1;j<n;j++)
	{
	  sum+=a[j];
	  if(sum==0)
	    {
	      counter++;
	      printf("s%d : {",counter);
	      int k;
	      for(k=i;k<j;k++)
		{
		  printf("%d , ",a[k]);                //Printing the sub arraies whose sum is 0
		}
	      printf("%d }\n",a[j]);
	    }
	}
    }
  //printf("\nNumber of possible sub-arrays = %d\n",counter);
  return 0;


}
