//VEDIC PARTAP 16CS10053 SECTION -5
//QUICK SORT 
#include<stdio.h>
int partition(int a[],int l,int r);
void quick_sort(int a[],int l,int r)  //FUNCTION FOR THE QUICK SORT
{
  if(l<r)
    {
      int p=partition(a,l,r);
      quick_sort(a,l,p-1);   //SORTING THE PARTITIONED ARRAY USING RECURSION 
      quick_sort(a,p+1,r);
    }
  return;
}
int partition(int a[],int l,int r)  //FUNCTION TO FIND THE PARTITION 
{
  int pivot =a[l];
  int i,j=l+1;
  for(i=l+1;i<=r;i++)
    {

      if(a[i]<=pivot)
	{
	  int temp=a[i];  //SWAPPING 
	  a[i]=a[j];
	  a[j]=temp;
	  j++;
	}
    }
  j--;
  int temp=pivot;  //SWAPPING 
  a[l]=a[j];
  a[j]=temp;
  return j;

}
int main()
{
 int n;
  printf("Give the number of the element : ");
  scanf("%d",&n);
  int a[n];
  int i;
  printf("Give the array ; ");//ACCEPTING THE ARRAY
  for(i=0;i<n;i++)
    {
      scanf("%d",&a[i]);
    }
 quick_sort(a,0,n-1);
 printf("The sorted array is :\n");
  for(i=0;i<n;i++)
    printf("%d ",a[i]);//PRINTING THE SORTED ARRAY 
  printf("\n");
  return 0;
}
