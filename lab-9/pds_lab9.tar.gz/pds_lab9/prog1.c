//VEDIC PARTAP 16CS10053 SECTION-5
//FINDING DATA FROM DATE OF BIRTH
#include<stdio.h>
struct date//STRUCT FOR THE DATE FORMAT
{
  int day;
  int month;
  int year;
};
struct record   //STRUCT FOR THE RECORD 
{
  int roll_no;
  char name[20];
  struct date dob;
};
int main()
{
  int n;
  printf("Giver the number of the student : "); //NUMBER OF THE STUDENT 
  scanf("%d",&n);
  int i;
  struct record data[n];
  for(i=0;i<n;i++)
    {
      printf("Give the roll no of student %d : ",i+1);  //ACCEPTING THE DATA
      scanf("%d",&data[i].roll_no);
      getchar();
      printf("Give the name of student %d : ",i+1);
      scanf("%[^\n]%*c",data[i].name);
      printf("Give the date of birth of student %d : ",i+1);
      scanf("%d/%d/%d",&data[i].dob.day,&data[i].dob.month,&data[i].dob.year);
    }
  printf("Give the date of birth to be found in format dd/mm/yyyy : "); //ACCEPTING THE DATE OF BIRTH
  int d,m,y,flag=0;;
  scanf("%d/%d/%d",&d,&m,&y);
  for(i=0;i<n;i++)
    {
      if(data[i].dob.day==d && data[i].dob.month==m && data[i].dob.year==y)
	{
	  printf("The data of the student is \n");  //PRINTING THE DATA 
	  printf("Roll No - %d\n",data[i].roll_no);
	  printf("Name    - %s\n",data[i].name);
	  printf("DOB     - %d/%d/%d\n",d,m,y);
	  flag=1;
	}
    }
  if(flag==0)
    {
      printf("Data not Found\n");
    }
  return 0;
}
