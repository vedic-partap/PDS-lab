//VEDIC PARTAP 16CS10053 SECTION 5
//MERGE SORT 
#include<stdio.h>

void merge(int a[],int l,int r);
void merge_sort(int a[],int l,int r) //FUNCTION FOR THE MERGE SORT
{
  if(l<r)
    {
      int mid=(l+r)/2;
      merge_sort(a,l,mid);  //RECURSION
      merge_sort(a,mid+1,r);
      merge(a,l,r);
    }
  return;
}
void merge(int a[],int l,int r) //FUNCTION FOR THE MERGING 
{
  int mid=(l+r)/2;
  int n=r-l+1;
  int b[n];
  int i=0,j=0,k=0;
  int q=mid-l+1;
  int w=r-mid-1+1;
  for(i=0;i<n;i++)
    {
      if((a[l+j]<=a[mid+1+k])&& l<q || k>=w)   //MERGING 
	{
	  b[i]=a[l+j];
	  j++;
	}
      else if((a[l+j]>a[mid+1+k])&&k<w || l>=q)
	{
	  b[i]=a[mid+1+k];
	  k++;
	}
    }
  for(i=0;i<n;i++)
    a[l+i]=b[i];
}
int main()
{
  int n;
  printf("Give the number of the element : ");
  scanf("%d",&n); 
  int a[n];
  int i;
  printf("Give the array ; ");
  for(i=0;i<n;i++)  //ACCEPTING THE ARRAY 
    {
      scanf("%d",&a[i]);
    }
  merge_sort(a,0,n-1);
 printf("The sorted array is :\n");
 for(i=0;i<n;i++)    //PRINT THE SORTING ARRAY
    printf("%d ",a[i]); 
  printf("\n");
  return 0;
}
