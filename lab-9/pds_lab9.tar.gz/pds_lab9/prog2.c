//VEDIC PARTAP 16CS10053 SECTION 5
//TERNARY SEARCH AND INTERPOLATION SEARCH
#include<stdio.h>
int ternary_search(int a[],int l,int r, int x)//FUNCTION FOR THE TERNARY SEARCH
{
    if(r>=l)
    {
      int mid1 = l + (r-l)/3;  //FINDING THE POINTS FOR DIVINDING 
        int mid2 = r -  (r-l)/3;
        if(a[mid1] == x)
            return mid1;
        if(a[mid2] == x)
            return mid2;
        if(x<a[mid1])
	  return ternary_search(a,l,mid1-1,x);  //RECURSION 
        else if(x>a[mid2])
	  return ternary_search(a,mid2+1,r,x);
        else
	  return ternary_search(a,mid1+1,mid2-1,x);

    }
    return -1;
}

void interpolation_search(int a[],int n,int k)  //FUNCTION FOR THE INTERPOLATION SEARCH 
{
 int  l=0,r=n-1;
  int flag =0;
  int m=0;
  while(flag==0)
    {
       m=((k-a[l])/(a[r]-a[l]))*(r-l)+l;
       //printf("%d\n",m);
      if(l<=m && m<=r)
	{
	  if(k<a[m])
	    r=m-1;
	  else if(k==a[m])
	    {
	      flag=1;
	       
	    }
	  else if(k>a[m])
	    l=m+1;
	}
      else
	break;
    }
  if(flag==1)
    printf("Element is present\n");
  else
    printf("Element is not present\n");
  return;

}
int main()
{
  int n;
  printf("Give the number of the element : ");
  scanf("%d",&n);
  int a[n];
  int i;
  printf("Give the sorted array ; ");  //ACCEPTING THE SORTED ARRAY 
  for(i=0;i<n;i++)
    {
      scanf("%d",&a[i]);
    }
	int k;
 printf("Give the element to be searched : ");
 scanf("%d",&k); 
 printf("From the interpolation Search\n");  
 interpolation_search(a,n,k);           //PRINTING THE INTERPOLATION SEARCH
 printf("\nFrom ternary Search\n");
int j= ternary_search(a,0,n-1,k);            //PRINTING THE TERNARY SEARCH 
 if(j==-1)
   printf("Element not found\n");
 else
   printf("Element is not present\n");
 return 0;
}
