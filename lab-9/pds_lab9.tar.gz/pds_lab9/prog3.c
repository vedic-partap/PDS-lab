//VEDIC PARTAP 16CS10053 SECTION-5
//INSERTION SORT 
#include<stdio.h>
void insertion_sort(int a[],int n) //FUNCTION FOR THE INSERTION SORT
{
  for(int i=1;i<n;i++)
    {
      for(int j=i;j>0;j--)
	{
	  if(a[j]<a[j-1])
	    {
	      int temp=a[j];
	      a[j]=a[j-1];
	      a[j-1]=temp;
	    }
	}
    }
  return ;
}
int main()
{
  int n;
  printf("Give the number of the element : "); //NUMBERS OF ELEMENT 
  scanf("%d",&n);
  int a[n];
  int i;
  printf("Give the array : ");
  for(i=0;i<n;i++)
    {
      scanf("%d",&a[i]);
    }
  insertion_sort(a,n);
  printf("The sorted array is :\n");  //PRINTING THE SORTED ARRAY
  for(i=0;i<n;i++)
    printf("%d ",a[i]);
  printf("\n");
  return 0;
}
