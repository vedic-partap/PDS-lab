//VEDIC PARTAP   16CS10053  SECTION-5
//DISTRIBUTUING THE NUMBERS IN THE RANGE 
/*In this the range written is ,e.g 4-7 the 7-10 the if the number is less than 7.5 the it is counted in the 4-7 unless in 7-10*/
#include<stdio.h>//HEADER FILES
#include<stdlib.h>

int main()
{
  int n;
  printf("Give the numbers of element : ");//GETTING THE NUMBER OF ELEMENTS
  scanf("%d",&n);
  float *f;                               //DEFING THE POINTER 
  f=(float*)malloc(n*sizeof(float));      //ALLOCATING THE MEMORY
  int i;
  for(i=0;i<n;i++)
    {
      printf("Give a number : ");        //GETTING THE NUMBERS 
      scanf("%f",f+i);
      
    }
  printf("Input : ");
  float min =10000.0,max=-10000.0; 
  for(i=0;i<n;i++)        //PRINTING THE INPUT AND GETTING THE MINIMUM AND THE MAXIMUM VALUE 
    {
      printf("%.2f ",*(f+i));  
      if(*(f+i)>max)
	{
	  max=*(f+i);
	}
      if(*(f+i)<min)
	{
	  min=*(f+i);
	}
    }
printf("\n--------------------------------------------------\n");
 printf("\nRange = %.2f - %.2f (minimum =%.2f ,maximum =%.2f)\n",min,max,min,max); //PRINTING THE MINIMUM AND THE MAXIMUM VALUE 
 float diff=(max-min)/4;                                                          //CALCULATING THE DIFFERENCE PER RANGE 
 float diff2=(max-min-3)/4;
  printf("Interval -1 = %.2f - %.2f \n",min,min+diff2);
 printf("Interval -2 = %.2f - %.2f \n",min+diff2+1,min+2*diff2+1);
 printf("Interval -3 = %.2f - %.2f \n",min+2*diff2+2,min+3*diff2+2);
 printf("Interval -4 = %.2f - %.2f \n",min+3*diff2+3,max);
 
 int *g;
 g=(int *)malloc(4*sizeof(int));                             //POINTER- TO STORE THE NUMBERS IN THE THE SPECIFIC RANGE 
 for(i=0;i<4;i++)*(g+i)=0;
 for(i=0;i<n;i++)                                          
   {
     if(*(f+i)>=min && *(f+i)<=min+diff)
       *g=*g+1;
     else if(*(f+i)>min+diff && *(f+i)<=min+2*diff)
       *(g+1)=*(g+1)+1;
     else if(*(f+i)>min+2*diff && *(f+i)<=min+3*diff)
       *(g+2)=*(g+2)+1;
     else  if(*(f+i)>min+3*diff && *(f+i)<=max)
       *(g+3)=*(g+3)+1;
   }
 printf("\n--------------------------------------------------\n");
 printf("Interval -1 = %.2f - %.2f   %d\n",min,min+diff2,*g);                   //PRINTING THR INTERVALS AND THE NUMBERS IN THAT SPECIFIC RANGE 
 printf("Interval -2 = %.2f - %.2f   %d\n",min+diff2+1,min+2*diff2+1,*(g+1));
 printf("Interval -3 = %.2f - %.2f   %d\n",min+2*diff2+2,min+3*diff2+2,*(g+2));
 printf("Interval -4 = %.2f - %.2f   %d\n",min+3*diff2+3,max,*(g+3));
 return 0;
}
