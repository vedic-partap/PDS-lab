//VEDIC PARTAP  16CS10053  SECTION-5
//LINKED LISTED 

#include<stdio.h>  //Header File 
#include<stdlib.h>
typedef struct Node{   //struct for the the linked list 
  int data;
  struct Node *next;
}node;
node *create(int a[])    //FUNCTION TO CREATE THE LINKED LIST 
{
  node*header,*temp,*new;             //DEFINING THE HEADER
  new=(node *)malloc(sizeof(node));  //ALOCATTING THE MEMORY 
  if(new==NULL)
    {
      printf("memory can't be allocated \n");
      return new;
    }
  else 
    {
      if(a[0]!=-1000)
	{
	new->data=a[0];
      new->next=NULL;
      temp=new;
      header=new;   //GIVING THE VALUE OF THE HEADER
	}
      else 
	{
	  header=NULL;
	  return header;
	}
      int i;
      for(i=1;a[i]!=-1000;i++)
	{
	  new=(node *)malloc(sizeof(node));
	  if(new==NULL)          //CONDITION CHECK IF THE MEMEORY IS ALLOCATED OR NOT 
	    {
	      printf("memory can't be allocated \n");
	      return new;
	    }
	  else 
	    {
	      new->data=a[i];
	      new->next=NULL;
	      temp->next=new;
	      temp=new;
	    }
	}
    }
  return header;  //RETURING THE HEADER 
}
void printl(node * h)  //PRINT FUNCTION FOR PRINTING THE LINKED LIST 
{
  node *temp;
  temp=h;
  if(h!=NULL)    //CHECKING IF THE LIST IS EMPTY OR NOT 
    {
      printf("%d ",temp->data);
	 while(temp->next!=NULL)
	   {
	     temp=temp->next;
	     printf("%d ",temp->data);
	   }
    }
  else 
    printf(" ");   //IF THE LIST IS EMPTY THEN PRINTING NOTHING 
  return ;
  
}


int main()
{
  node *header,*h2,*h3;int n;  //DEFING THE INPUTED LIST AND THE LIST TO BE MADE FROM THE NEGATIVE NUMBERS
  printf("Give the number of element : ");  //ACCEPTING THE NUMBER OF THE ELEMENTS
  scanf("%d",&n);
  int a[100],b[100],c[100];
  int i;
  for(i=0;i<100;i++)
    {
      a[i]=-1000;b[i]=-1000;c[i]=-1000;
    }
  for(i=0;i<n;i++)                    
    {
       printf("Give the value :");   
      scanf("%d",&a[i]);
    }
  header=create(a);
  node *new;
  node *temp;
  temp=header;
  printf("The input list is : ");  //PRINTING THE INPUTED LIST 
  printl(header);
  int e=0,d=0;
  if(temp->data<=0)
    {
      b[e]=temp->data;
      e++;
    }
  else 
    {
      c[d]=temp->data;
      d++;
    }
 
  while(temp->next!=NULL)
    {
      temp=temp->next;
      if(temp->data<=0)     //CHEKING THE CONDITION IF THE THE NUMBER IS NEGATIVE OR NOT 
    {
      b[e]=temp->data;
      e++;
    }
 else                      
    {
      c[d]=temp->data;
      d++;
    }
 
    }
  header=create(c);   //UPDATING THE OLD LIST 
  h3=create(b);         //ASSIGNING THE HEADER TO THE NEW LIST 

  printf("\n\nThe new list is : ");  //PRINTING THE RESULTS 
  printl(h3);
  printf("\nUpdated list is : ");  
  printl(header);
  printf("\n");
  return 0;
}
