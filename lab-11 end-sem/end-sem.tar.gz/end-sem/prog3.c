//VEDIC PARTAP  16CS10053  SECTION -5
//CALCULATING THE POSTFIX EXPRESSION 
/*The values have been roun off to two decimal digit so the subsequent calculations has been also rounde hance there may be some difference */


#include<stdio.h>   //HEADER FILE 
#include<stdlib.h>
typedef struct lifo//STRUCT FOR THE STACK WITH THE TYPEDEF 
{  
  float a[100];
  int top;
}stack;
stack s;
void create()  //FUNCTION TO CREATE THE STACK 
{
  s.top=-1;
}
void push(float c)  //FUNCTION TO PUSH THE VALUE IN THE STACK
{
  s.top++;
  s.a[s.top]=c;
}
void pop()     //FUNCTION TO POP THE VALUE IN THE STACK 
{
  s.top--;
}
int isempty()  //FUNCTION TO CHECK IF THE STACK IS EMPTY OR NOT 
{
  if(s.top==-1)
    return 1;
  else return 0;
}
float topel()  //TO PRINT THE TOP ELEMENT OF THE STACK 
{
  return s.a[s.top];
}
float round(float f) //FUNCTION TO ROUND OFF THE FLOATING NUMBER 
{
  int i;
  i=f*1000+0.005;
  return i/1000.0;
}

int main()
{
  create();
  char c[30];
  printf("Give the expression to be evaluated :");  //GETTING THE EXPRESSION 
  scanf("%s",c);
  int i;
  for(i=0;c[i]!='\0';i++)
    {
      if(c[i]>='0' && c[i]<='9')  //PUSING THE OPERAND IN THE STACK 
	{
	  push(c[i]-'0');
	}
     
      else if(c[i]=='+')  //POPING THE OPERANDS AND THE EVALUATING THE VALUE AND THEN PUSHING THE CALCULATED VALUE IN THE STACK
	{
	  float x,y;
	  x=1.0*topel();
	  pop();
	  y=1.0*topel();
	  pop();
	  push(round(x+y));
	}
      else if(c[i]=='-')
	{
	  float x,y;
	  x=1.0*topel();
	  pop();
	  y=1.0*topel();
	  pop();
	  push(round(y-x));
	}
      else if(c[i]=='/')
	{
	  float x,y;
	  x=1.0*topel();
	  pop();
	  y=1.0*topel();
	  pop();
	  push(round(y/x));
	}
      else if(c[i]=='*')
	{
	  float x,y;
	  x=1.0*topel();
	  pop();
	  y=1.0*topel();
	  pop();
	  push(round(x*y));
	}
    }
  float result =topel();
  printf("The value of the expression is : %.2f \n",result);  // PRINTING THE RESULT 
  return 0;
}
