//VEDIC PARTAP 16CS10053 SECTION 5
//BINARY SEARCH 

#include<stdio.h> 
void bubblesort(float a[],int n)  //SORTING THE ARRAY USING THE BUBBLE SORT
{
  int count=1,i,j;
  while(count!=0)
    {
      count=0;
      for(i=1;i<n;i++)
	{
	  if(a[i]<a[i-1])
	    {
	      float temp=a[i];
	      a[i]=a[i-1];
	      a[i-1]=temp;
	      count++;
	    }
	}
    }
}

int binary(float a[],int n,int m)   // FUNCTION FOR BINARY SEACHING A ELEMENT
{
  int l=0;int r=n-1;
  while(l<=r)
    {
      if(l==r)

	{
	  if(a[l]==m)
	    {
	      return 1;
	    }

	  else
	    return 0;
	}
      else
	{
	  int mid=(l+r)/2;
	  if(a[mid]==m)
	    {
	      return 1;
	    }
	  if(m<a[mid])
	    {
	      r=mid-1;
	    }
	  if(m>a[mid])
	    {
	      l=mid+1;
	    }
	}
    }  
}
int main()
{
  int n;
  printf("The size of the array : ");
  scanf("%d",&n);
  float a[n];
  int i;
  for(i=0;i<n;i++)
    {
      scanf("%f",&a[i]);
    }
  bubblesort(a,n);   // SORTING A GIVEN ARRAY
  float x;
  printf("Give the number to be searched : ");
  scanf("%f",&x);
  if(binary(a,n,x)==1)
    {
      printf("The element is present in the array\n");   // FINDING THE NUMBER

    }
  else
    printf("The element is not present in the array\n");
  return 0;
}
