//VEDIC PARTAP 16CS10053 SECTION 5


#include<stdio.h>
void bubblesort(float a[],int n)  // SORTING THE ARRAY USING THE BUBBLE SORT---SWAPPING THE NUMBERS WHILE TRAVERSING THE ARRAY WHICH ARE NOT IN ACENDING ORDER
{
  int count=1,i,j;
  while(count!=0)
    {
      count=0;
      for(i=1;i<n;i++)
	{
	  if(a[i]<a[i-1])
	    {
	      float temp=a[i];
	      a[i]=a[i-1];
	      a[i-1]=temp;
	      count++;
	    }
	}
    }
}
int main()
{
  int n;
  printf("Give the size of the array : ");  //ACCEPTING THE SIZE OF THE ARRAY
scanf("%d",&n);
float a[n];
int i=0;
for(i=0;i<n;i++)
  {
    printf("Give the number : ");
    scanf("%f",&a[i]);
  }
 bubblesort(a,n);
for(i=0;i<n;i++)
  printf("%f ",a[i]);     //PRINTING THE SORTED ARRAY
 printf("\n");
return 0;
}
