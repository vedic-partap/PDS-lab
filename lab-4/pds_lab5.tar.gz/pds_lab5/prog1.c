//VEDIC PARTAP 16CS10053 SECTION 5


#include<stdio.h>
#include<math.h>
float square(float n) //FUNCTION OF SQUARING A NUMBER
{
  return (n*n);
}

float average(float a[],int n)//FINDING AN AVERAGE OF THE ARRAY
{
  int i;
  float sum=0.0;
  for(i=0;i<n;i++)
    sum+=a[i];
  return sum/n;
}

int main()
{
  int n;
  printf("Enter the size of the array : ");//ACCEPTING A ARRAY
  scanf("%d",&n);
  float a[n];
  int i;
  for(i=0;i<n;i++)
    {
      printf("give the element : ");
      scanf("%f",&a[i]);
    }
  float mean_array=average(a,n);
  float sq_mean=square(mean_array);
  float mean_sq=0;
  int j;
  for(j=0;j<n;j++)
    {
      mean_sq+=square(a[j]);
    }
  mean_sq=mean_sq/n;
  float var=(mean_sq-sq_mean);//FINDING THE VARIANCE OF THE NUMBERS
  float sd= sqrt(var);      //FINDING THE STANDARD DEVIATION OF THE NUMBERS

  printf("The variance of the values entered is %f\nthe standard deviation is %f\n",var,sd);
  return 0;

}
