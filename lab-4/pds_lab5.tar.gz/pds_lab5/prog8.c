#include<stdio.h>
int ifExist(int i,int j,int a,int b)
{
  if(i>=0 && i<a && j>=0 && j<b)
    {
      return 1;
    }
  return 0;
}
int main()
{
  int a,b;
  printf("Give the no of rows ; ");
  scanf("%d",&a);
  printf("Give the no of cols ; ");
  scanf("%d",&b);
  int c[a][b];
  int i,j;
  for(i=0;i<a;i++)
    {
      for(j=0;j<b;j++)
	{
	  scanf("%d",&c[i][j]);
	}
    }
  i=0;j=0;
  int count=0;int temp;
  for(i=0;i<a;i++)
    {temp=i;
      //printf("%d ",a[j][0]);
      while(ifExist(i,j,a,b)==1)
	{
	  printf("%d ,",c[i][j]);
	  i=i-1;
	  j=j+1;

	} i=temp;
      j=0;

	    printf("\n");
    }
  i=a-1;
for(j=1;j<b;j++)
    {temp=j;
      //printf("%d ",a[j][0]);
      while(ifExist(i,j,a,b)==1)
	{
	  printf("%d ,",c[i][j]);
	  i=i-1;
	  j=j+1;

	} j=temp;
          i=a-1;

	    printf("\n");
    }
	return 0;
}
