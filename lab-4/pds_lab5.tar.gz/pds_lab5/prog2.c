//VEDIC PARTAP 16CS10053 SECTION 5

#include<stdio.h>
void reverse(char a[])  //****FUNCTION FOR REVERSING THE ARRAY
{
  int i;
  for(i=0;a[i]!='\0';i++);
  int j;i--;
  for(j=0;j<=i;j++,i--)
    {
      char temp;
      temp =a[i];
      a[i]=a[j];
      a[j]=temp;
    }
    
}
int cmp(char a[],char b[])   //*****FUNCTION FOR THE COMPARISION OF THE TWO STRING
{
  int i;
  for(i=0;a[i]!='\0';i++)    
    {
      if(a[i]!=b[i])
	return a[i]-b[i];
    }
  if(a[i]!=b[i])
    return a[i]-b[i];
  return 0;              //RETURNING THE VALUE OF THE DIFFERENCE IN THE ASCII VALUE OF THE DIFFERENTIATING CHARACTER
}
int main()
{
  char a[30],b[30],temp[30],temp2[30];
  int h;int g;

 
  printf("Give a string : ");   //ACCEPTING THE STRING
  scanf("%[^\n]%*c",a);  
  printf("Give another string :"); //ACCEPTING THE STRING
  scanf("%[^\n]%*c",b);
 for(h=0;a[h]!='\0';h++)
    temp[h]=a[h];
 temp[h]='\0';
for(g=0;b[g]!='\0';g++)
    temp2[g]=b[g];
 temp2[g]='\0';
 if(cmp(a,b)==0)                 //COMPARING THE STRING
    printf("The string are equal\n"); 
  else
    printf("The strings are not equal\n");
  reverse(a);
  printf("\nThe reverse of the string 1 is %s \n",a);  //PRINTING THE REVERSE OF THE STRING
reverse(b);
  printf("\nThe reverse of the string 2 is %s \n",b);  //PRINTING THE REVERSE OF THE STRING
  
 
 
if(cmp(a,temp)==0)
  printf("The string 1 is palindrome\n");                //CHECKING THE PALINDROME OR NOT
  else
    printf("The string 1 is not palindrome\n");
if(cmp(b,temp2)==0)
  printf("The string 2 is palindrome\n");                //CHECKING THE PALINDROME OR NOT
  else
    printf("The string 2 is not palindrome\n");
 
  return 0;
}
