//VEDIC PARTAP 16CS10053 SECTION 5
//FINDING THE LCM OF TWO NUMBERS

#include<stdio.h>
int coprime(int a,int b) // FUNCTION TO CHECK IF THE TWO NUMBERS ARE CO-PRIME OR NOT_____ RETURN 0-FALSE 1- TRUE
                        
{
  if(a<b)
    {
      int temp;
      temp=a;
      a=b;
      b=temp;
    }
  for(int i=2;i<=b;i++)
    {
      if(a%i==0 && b%i==0)
	{
	  return 0;
	}
    }
  return 1;

}

int main()
{
  int a,b;
  long long l=1;
  printf("give an number : ");
  scanf("%d",&a);
  printf("give an another number ");
  scanf("%d",&b);
  while(coprime(a,b)==0)   // DIVIDE BY COMMON DIVISOR TILL THE TWO NUMBERS REMAIN CO PRIME
    {
      if(a<b)
    {
      int temp;
      temp=a;
      a=b;
      b=temp;
    }
      int i;
      for(i=2;i<=b;i++)   // DIVIDING BY PRIME FACTORS
    {
      if(a%i==0 && b%i==0)
	{
	  a=a/i;
	  b=b/i;
	  l=l*i;
	}
    }
  
    }
  l=l*a*b;
  printf("The lcm ofthe numbers is %lld \n",l);
  return 0;

}
