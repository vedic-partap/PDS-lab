//VEDIC PARTAP  16CS10053  SECTION 5


#include<stdio.h>
float c(float n)     //FUNCTION FOR FINDING THE COS OF THE VALUE IN GIVEN PRECISION
{
  int i;
  float sum=1,e=0,value=1;
  
    {
  for(i=1;i<=1000;i++)
    {

      float p_sum=sum;
      value =value*n/i;
      if(i%4==2)
	{
	 
	    sum-=value;
	}
      if(i%4==0)
	{
  
	  sum+=value;
	}
      if((p_sum-sum>0 && p_sum-sum<=0.00001)||(sum-p_sum>0 && sum-p_sum<=0.00001)) //CHECKING THE PRECISION VALUE
	 break;
    }
      return sum;
    }
}
int main()
{
  float n;
  printf("Give the angle : ");
  scanf("%f",&n);
  
  float cos=c(n*3.14159/180);
  printf("The value of the cos(n) = %f ",cos);  // PRINTING THE COS OF THE GIVEN FUNCTION
  return 0;
}
