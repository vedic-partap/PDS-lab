//VEDIC PARTAP  16CS10053  SECTION 5
//SORTING AN ARRAY BY RECURSION

#include<stdio.h>
void sort(int a[],int l,int r);  //PROTOTYPE OF THE SORT FUNCTION
int main()
{
  int n;
  printf("Give the size of the array : ");
  scanf("%d",&n);
  int a[n];
  int i=0;
  for(i=0;i<n;i++)
    {
      printf("Give me a integer : ");
      scanf("%d",&a[i]);
    }
  
  printf("The input array is : ");
for(i=0;i<n;i++)
    printf("%d ",a[i]);
 printf("\n");
sort(a,0,n-1);
  printf("The sorted array is : ");
  for(i=0;i<n;i++)
    printf("%d ",a[i]);
  printf("\n");
  return 0;
}
void sort(int a[],int l,int r)  //SORTING THE ARRAY 
{
  if(l==r)                     //BASE CASE
    return ; 
  else
    sort(a,l+1,r);            //RECURSIVE CALLING OF THE FUNCTION
  int i=0;
  int temp=a[l];
  for(i=l;i<r;i++)
    {
      if(a[i]>a[i+1])
	{
	  int tep=a[i];
	  a[i]=a[i+1];
	  a[i+1]=tep;
	}
      else
	return ;
    }
}
