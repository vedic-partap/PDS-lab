//VEDIC PARTAP  16CS10053  SECTION 5
//TO FIND nCr RECURSIVELY

#include<stdio.h>
static int counter=0;    //VARIABLE TO CHECK THE NO. OF TIMES THE choose FUNCTION IS CALLED
int choose(int n,int r)  //FUNCTION -choose
{ counter++;  
  if(n<r)
    {
      printf("n must be greater the r\n");
      return 0;
    }
  
 
  if(r==0)        //BASE CASE
    return 1;
  else if(n==r)
    return 1;
  else 
    return choose(n-1,r)+choose(n-1,r-1); //RECURSIVE CALL OF THE FUNCTION 

}
int main()
{
  int n,r;
  printf("Enter the value of the n : ");
  scanf("%d",&n);                           // ACCEPTING THE VALUE OF n
  printf("Enter the value of the r : ");
  scanf("%d",&r);
  printf("The value of the nCr is %d\n",choose(n,r));                //CALLING THE choose FUNCTION IN main()
  printf("The no. of the times the choose function is called is %d \n",counter);
  return 0; 
}
