//VEDIC PARTAP  16CS10053  SECTION 5
//FINDING THE COS OF THE VALUE ANGLE

#include<stdio.h>
double power (double x,int n);  //PROTOYTYPE OF THE FUNCTIONS USED 
int fact(int n);
double cos(double x,int n);
int main()
{
  double x;
  int n;
  printf("Give the angle in degree : ");
  scanf("%lf",&x);
  printf("Give the number of terms : ");
  scanf("%d",&n);
  double temp =x;
  x=x*3.14159/180;    //CONVERTING THE DEGREEE TO RAD.
  double c=cos(x,n); //CALLING THE COS FUNCTION
  printf("The cos(%f) is %f\n",temp,c);
  return 0;
}

double power (double x,int n)  //POWER FUNCTION
{
  if(n==1)      //BASE CASE
    return x;
  else
    return x*power(x,n-1);    //RECURSIVE CALLING OF THE POWER FUNCTION
}

int fact(int n)               //FACTORIAL FUNCTION
{
  if(n==1)                    //BASE CASE
    return 1;
  else
    return n*fact(n-1);       //RECURSIVE CALLING OF THE FACTORIAL FUNCTION
}
double cos(double x,int n)    //COS FUNCTION
{
  if(n==1)                    //BASE CASE
    return 1;

  if(n%2==0)
    return cos(x,n-1)-power(x,2*(n-1))/fact(2*(n-1)); //RECURSIVE CALLING OF THE COS FUNCTION
  if(n%2==1)
    return cos(x,n-1)+power(x,2*(n-1))/fact(2*(n-1));
}
