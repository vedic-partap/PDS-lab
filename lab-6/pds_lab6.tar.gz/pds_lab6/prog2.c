//VEDIC PARTAP  16CS10053 SECTION 5
//FINDING THE SUM OF THE DIGITS OF THE NUMBER

#include<stdio.h>
int sumOfDigit(int n);    //PROTOTYPE OF THE FUNCTION 
int main()
{
  int n;
  printf("Give a number n : ");
  scanf("%d",&n);
  int s=sumOfDigit(n);
  printf("The sum of the digits of the %d is %d\n",n,s);
  return 0;
}

int sumOfDigit(int n)      //DECLARATION OF THE FUNCTION
{
  if(n<10)    //BASE CASE
    return n;
  else
    return n%10+sumOfDigit(n/10);   //RECURSIVE CALL OF THE FUNCTION 
}
