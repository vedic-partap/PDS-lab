//VEDIC PARTAP  16CS10053 SECTION 5
//FINDING THE POWER OF THE FUNCTION

#include<stdio.h>
float power(float x,int n);  //PROTOTYPE OF THE FUNCTION
int main()
{
  float x;
  int n;
  printf("Give me a real number x : ");
  scanf("%f",&x);
  printf("Give the value of the power n( integer ) : ");
  scanf("%d",&n);
  float result=power(x,n);
  printf("The x^n is %f \n",result);
  return 0;
}
float power (float x,int n)    //DECLARATION OF THE FUNCTION
{
  if(x==0 && n<0)
    {
    printf("for the negative value of n the value of x must be non-zero\n");
  return 0;
    }
  if(n==0)                    //FOR n=0
    return 1;
  else if(n>0)                //FOR POSITIVE N
    {
      if(n==1)  //BASE CASE
	return x;
      else
	return x*power(x,n-1);
    }
  else      //FOR NEGATIVE N
    {
      float pow=power(x,-n);
      return 1.00/pow;
    }
}
